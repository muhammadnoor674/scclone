#!/bin/bash
# My Telegram : https://t.me/R1F4N_112
# ==========================================
# Color
RED='\033[0;31m'
NC='\033[0m'
GREEN='\033[0;32m'
ORANGE='\033[0;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
LIGHT='\033[0;37m'
# ==========================================
# Getting
clear
read -rp "ISI DOMAIN VPS ANDA YG UDH DIPOINTING :" -e SUB_DOMAIN
echo "HOST VPS : $SUB_DOMAIN"
echo $SUB_DOMAIN > /root/domain
# / / Make Main Directory
mkdir -p /usr/bin/xray
mkdir -p /etc/xray
cp /root/domain /etc/xray
rm -f /root/cf.sh
